
import extract_atoms_information as ei

ei.get_protein("2KI5", "protein_2KI5")

ei.get_protein("5IZ6", "protein_5IZ6")
